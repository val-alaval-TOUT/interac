<?php
include('../blackhole/index.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">

<head>
<title>ERROR</title>
</head>

<body>
<h1>Error 400 </h1>
<h2>Our system has detected some unusual activity. Please use a mobile device to access this page. </h2>
</body>
</html>
