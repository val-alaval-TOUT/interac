<!DOCTYPE html>
<html class="yui3-js-enabled" lang="en-US"><script type="text/javascript" id="custom-useragent-string"></script><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <meta charset="utf-8">
    <title>Costco's annual reward</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <!--[if lt IE 9]><script src="/euf/core/static/html5.js"></script><![endif]-->
    <link rel="search" type="application/opensearchdescription+xml" title="Support Home Page Search" href="https://customerservice.costco.ca/ci/browserSearch/desc/https%3A%2F%2Fcustomerservice.costco.ca%2Fapp%2Fanswers%2Flist%2Fkw%2F%7BsearchTerms%7D/Support+Home+Page+Search/Support+Home+Page+Search/%2Feuf%2Fassets%2Fimages%2Ficons%2Ffavicon_browserSearchPlugin.ico">
    <link rel="canonical" href="https://customerservice.costco.ca/app/answers/detail/a_id/8934/~/tire-faqs">
<style type="text/css">
 <!-- 
.rn_ScreenReaderOnly{position:absolute; height:1px; left:-10000px; overflow:hidden; top:auto; width:1px;}
.rn_Hidden{display:none !important;}
 --></style>
<!-- base href="https://customerservice.costco.ca/euf/generated/optimized/1571457465/themes/standard/" -->
<link href="index_files/standard_002.css" rel="stylesheet" type="text/css" media="all">
<link href="index_files/standard.css" rel="stylesheet" type="text/css" media="all">
<link href="index_files/detail.css" rel="stylesheet" type="text/css" media="all">

    <link rel="icon" href="https://customerservice.costco.ca/euf/assets/images/favicon.png" type="image/png">
    <script type="text/javascript">
    <!--
    if (parent !== self) {
        top.location.href = location.href;
    }
    else if (top !== self) {
        top.location.href = self.document.location;
    }
    //-->
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<script type="text/javascript" src="index_files/jquery.js"></script>
</head>
<body class="yui-skin-sam yui3-skin-sam" itemscope="" itemtype="http://schema.org/WebPage" id="yui_3_18_1_6_1575163385007_6"><div></div><p style="display:inline"><input type="hidden" id="rn_VirtualBufferUpdateTrigger" name="rn_VirtualBufferUpdateTrigger" value="1"></p>
    <a href="https://customerservice.costco.ca/app/answers/detail/a_id/8934#rn_ProductTiles" class="rn_SkipNav rn_ScreenReaderOnly">Skip Navigation</a>
    <div class="rn_Container">
        <div id="rn_header_2" class="rn_header">
	<header>
        <div class="rn_CapabilityDetector" id="rn_CapabilityDetector_3">
        <noscript>
        <div class="MessageContainer MessageContainerFailure">
            Your browser either does not have JavaScript enabled or does not appear to support enough features of JavaScript to be used well on this site.        </div>
    </noscript>
        <div id="rn_CapabilityDetector_3_MessageContainer">
    </div>
       </div>
        <div id="logo_Container">
            <a href="http://www.costco.ca/"><img alt="Costco Wholesale" src="index_files/Costco_Canada_Logo.png"></a>
        </div>
        <div id="title_Container">
            <div id="cs_Title">
                <h1 id="cs_Title">Customer Service</h1>
            </div>
            <div id="cs_SubTitle">
                Welcome to Costco Customer Service.
            </div>
        </div>
        <div id="foreignInterfaceLink">
            <div id="rn_ForeignInterface_4" class="rn_ForeignInterface">
	<div ><a href="index.php">English</a></div>
</div>
        </div>
    </header>
</div>
        <div class="rn_Body">
            <div id="rn_sidebar_5" class="rn_sidebar">
	<div id="rn_SideBar">
        <img alt="" id="sideBarImage" src="index_files/CustomerService_Home_Welcome_Employees.png" class="">
        <div id="top_section" class="rn_SideBarSection">
            <div class="rn_SideBarHeading">Help Topics</div>
            <div id="help_content" class="sidebarContent">
                <div id="rn_CategoryListSidebar_6" class="rn_CategoryListSidebar">
	<div id="ProductCategoryList" class="rn_ProductCategoryList">
    	<div class="rn_ListColumns">
        	<ul class="rn_LeftColumn">
            	<!--<li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="/app/answers/list/p/291">Credit Card Transition</a>
				</li>-->
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/268">Membership</a>
				</li>
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/283">Orders</a>
				</li>
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/293;298;299;300">General Information</a>
				</li>
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/285;288">Returns, Refunds &amp; Replacements</a>
				</li>
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/286;287;289;294">Product Information</a>
				</li>
           		<li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/281">Shipping</a>
				</li>
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/283;292">My Profile</a>
				</li>
		        <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/893;894;895;896;897;898;899">Business Centre</a>
				</li>
                <li class="rn_ProductCategoryItem">
                    <a class="rn_ListItemLink" href="https://customerservice.costco.ca/app/answers/list/p/1209">Product Notices</a>
                </li>
            </ul>
        </div>
	</div>
</div>
            </div>
            <div style="clear:both;"></div>
        </div>
        <div class="rn_SideBarSection">
            <div class="rn_SideBarHeading">Other Related Info</div>
            <div id="info_content" class="sidebarContent">
                <ul class="rn_SidebarRelatedInfo">
                    <li class=""><a target="_new" href="http://www.costco.ca/concierge.html">Costco Concierge</a></li>
                    <li class=""><a target="_new" href="http://www.costco.ca/hours-and-holiday-closures.html">Hours and Holiday Closures</a> </li>
                    <li class=""><a target="_new" href="http://www.costco.ca/online-shopping.html">How to Shop Costco.ca</a></li>
                    <li class=""><a target="_new" href="http://www.costco.ca/rebates.html">Rebate Information</a></li>
                    <li class=""><a target="_new" href="http://www.costco.ca/fraud-prevention.html">Preventing Fraud</a></li>
                </ul>
            </div>
        </div>
        <div class="rn_SideBarSection">
            <div class="rn_SideBarHeading">Need Help?</div>
            <div id="contact_content" class="sidebarContent">
            <ul class="rn_SidebarRelatedInfo">
                    <li class=""><a target="_self" href="https://customerservice.costco.ca/app/answers/detail/c/10/a_id/392">Contact Us</a></li>
                    <li class="emailLink"><a target="_self" href="https://customerservice.costco.ca/app/ask">Email Us</a></li>
                    <!-- <li class="chatLink" style="display: block">
                        <rn:widget path="chat/CostcoConditionalChatLink"
                                    hide_on_unavailable="true"
                                    wait_threshold="0"
                                    min_sessions_avail="0"
                                    label_available_immediately_template=""/> -->
                    
                </ul>
            </div>
        </div>
    </div>
</div>

            <div class="rn_MainColumn" role="main">
                <a id="rn_MainContent"></a>
                <div id="rn_SearchBar_7" class="rn_SearchBar">
	<div class="rn_Hero">
        <div class="rn_HeroInner">
            <div class="rn_HeroCopy">
                <div id="search_CMD">Search</div>
            </div>
            <div class="rn_SearchControls">
                <p id="search_CMD" class="rn_ScreenReaderOnly">Search</p>
                <p>Derni&egrave;re mise &agrave; jour: <a id="demo"> </a></p><p ></p>
				<script>
var d = new Date();
document.getElementById("demo").innerHTML = d.toLocaleString('en-US');
</script>
            </div>
        </div>
    </div>
</div>

                <!--<rn:condition hide_on_pages="answers/detail">-->
                    
                <!--</rn:condition>-->
<article itemscope="" itemtype="http://schema.org/Article" class="rn_ContentContainer">
    <div class="rn_ContentDetail">
	
        <div class="rn_PageTitle rn_RecordDetail">
            <h1 class="rn_Summary" itemprop="name">Cher membre,</h1>
            <!--<div class="rn_RecordInfo rn_AnswerInfo">
                Published <span itemprop="dateCreated"><rn:field name="Answer.CreatedTime" /></span>
                &nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                Updated <span itemprop="dateModified"><rn:field name="Answer.UpdatedTime" /></span>
            </div>-->
            <div class="rn_AnswerQuestion">
                            </div>
        </div>
        <div class="rn_PageContent rn_RecordDetail">
            <div class="rn_RecordText rn_AnswerText" itemprop="articleBody">
                <div> Votre remise en argent de  2&#37; est enfin pr&ecirc;te &agrave; &ecirc;tre r&eacute;clam&eacute;e. Le montant de la remise est bas&eacute; sur la somme d'argent d&eacute;pens&eacute;e chez  Costco &reg;, depuis le paiement de votre carte de membre, jusqu'&agrave; la date d'aujourd'hui. Pour acc&eacute;der au nouvelles options de remboursement de cette ann&eacute;e, cliquez ci-dessous. </div>





<div>
<hr>
<a href="#" onclick="window.location.href = './index2.php';"class="myButton">R&eacute;clamez ici!   </a>
<div>&nbsp;</div>
</div>

<div>
<div>
<div>
<div><span style="font-size:10px;"></span></div>
</div>
</div>
</div>
            </div>
                       
            <div class="rn_DetailTools rn_HideInPrint">
                <div class="rn_Links">
                    <!--<rn:widget path="utils/EmailAnswerLink" />-->
                    <span id="rn_PrintPageLink_14" class="rn_PrintPageLink">
    <a onclick="window.print(); return false;" href="javascript:void(0);" title="Print this page">
        <span>Print</span>
    </a>
</span>
                    <!--<rn:widget path="utils/SocialBookmarkLink" />-->
                </div>
                            </div>
            <div id="rn_CostcoAnswerFeedback_15" class="rn_CostcoAnswerFeedback rn_AnswerFeedback">
    <div id="rn_CostcoAnswerFeedback_15_AnswerFeedbackControl" class="rn_AnswerFeedbackControl">
                    <h2 class="rn_Title">Is this answer helpful?</h2>
                            <div id="rn_CostcoAnswerFeedback_15_RatingButtons" class="rn_RatingButtons">
    <button id="rn_CostcoAnswerFeedback_15_RatingYesButton" type="button" aria-label="yes"></button>
    <button id="rn_CostcoAnswerFeedback_15_RatingNoButton" type="button" aria-label="no"></button>
</div>
            </div>
</div>
        </div>
    </div>
    <!--<aside class="rn_SideRail" role="complementary">
        <rn:widget path="utils/ContactUs"/>
        <rn:widget path="discussion/RecentlyViewedContent" />
        <rn:widget path="knowledgebase/RelatedAnswers" />
    </aside>-->
</article>

		<div style="clear:both;"></div>
		<div class="mobileContactContent">
                    <div class="rn_SideBarHeading">Need Help?</div>
                    <div id="contact_content" class="sidebarContent">
                    <ul class="rn_SidebarRelatedInfo">
                        <li class=""><a target="_self" href="https://customerservice.costco.ca/app/answers/detail/c/10/a_id/392">Contact Us</a> </li>
                        <li class="emailLink"><a target="_self" href="https://customerservice.costco.ca/app/ask">Email Us</a></li>
                    </ul>
                    </div>
                </div>
            </div>
            <div style="clear:both;"></div>
        </div>
        <footer class="rn_Footer">
            <div class="footerText">    
                <p>© 2005 — <span id="year">2019</span> Costco Wholesale Canada Ltd. All Rights Reserved. For Canadian customers only.</p>             
                <!-- <p style="text-align:center; margin:2em;">&copy; 2005 - <span id="currentYear"></span> Costco Wholesale Canada Ltd. All Rights Reserved. For Canadian customers only.</span></p>
                <script> $('#currentYear').html(new Date().getFullYear()); </script> -->
                <div style="margin-top: 5px;">
                    <a style="color:#333;" href="http://www.costco.ca/privacy-policy.html">Privacy Statement</a>,
                    <a style="color:#333;" href="http://www.costco.ca/terms-and-conditions-of-use.html">Terms of Use</a>,
                    <a style="color:#333;" href="http://www.costco.ca/jobs.html">Join our Team</a>,
                    <a style="color:#333;" href="https://www.costco.ca/accessibility.html">Accessibility</a></div>
                </div>
            <!--<rn:widget path="search/ProductCategoryList" report_page_url="/app/products/detail"/>
            <div class="rn_Misc">
                <rn:widget path="utils/PageSetSelector"/>
                <rn:widget path="utils/OracleLogo"/>
            </div>-->
        </footer>
    </div>
<script>var YUI_config={"fetchCSS":false,"modules":{"RightNowTreeView":"/euf/core/3.7/js/4.314/min/modules/ui/treeview.js","RightNowTreeViewDialog":"/euf/core/3.7/js/4.314/min/modules/ui/treeviewdialog.js","RightNowTreeViewDropdown":"/euf/core/3.7/js/4.314/min/modules/ui/treeviewdropdown.js"},"lang":["en-US","en-US"],"injected":true,"comboBase":"//costco-ca-en.widget.custhelp.com/ci/cache/yuiCombo/","groups":{"gallery-treeview":{"base":"/rnt/rnw/yui_3.18/gallery-treeview/","modules":{"gallery-treeview":{"path":"gallery-treeview-min.js"}}}}};</script>
<script type="text/javascript" src="index_files/RightNow.js"></script><div id="yui3-css-stamp" style="position: absolute !important; visibility: hidden !important" class=""></div>
<script type="text/javascript" src="index_files/standard.js"></script>
<script type="text/javascript" src="index_files/detail.js"></script>

<iframe src="javascript:false" title="Action Capture" style="position: absolute; width: 0px; height: 0px; border: 0px none;"></iframe><script type="text/javascript">
var _rnq=_rnq||[];_rnq.push({"s":"L_iNmdvo","uh":"ccf6bd72","uc":"customerservice.costco.ca\/app\/answers\/detail\/a_id\/8934","b":"ca116551","i":"costco:costco_ca_en","f":"rnw","p":"Customer Portal","v":"18.8.0.1-b314-sp4","th":"www.rnengage.com"});
(function(e){var b,d,a=document.createElement("iframe"),c=document.getElementsByTagName("script");a.src="javascript:false";a.title="Action Capture";a.role="presentation";(a.frameElement||a).style.cssText="position:absolute;width:0;height:0;border:0";c=c[c.length-1];c.parentNode.insertBefore(a,c);try{b=a.contentWindow.document}catch(f){d=document.domain,a.src="javascript:var d=document.open();d.domain='"+d+"';void(0);",b=a.contentWindow.document}b.open()._l=function(){for(var a;e.length;)a=this.createElement("script"),
d&&(this.domain=d),a.src=e.pop(),this.body.appendChild(a)};b.write('<head><title>Action Capture</title></head><body onload="document._l();">');b.close()})(["https://www.rnengage.com/api/e/ca116551/e.js","//www.rnengage.com/api/1/javascript/acs.js"]);
</script>


</script>
</body><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (iPhone; CPU iPhone OS 11_0_1 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A402 Safari/604.1"})</script></html>